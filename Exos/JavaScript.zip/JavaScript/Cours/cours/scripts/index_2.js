



let arrExample = [3, 5, 8, 12, 2, 43, 21, 2, 3, 42, 2, 5, 12, 555, 2, 43, 21, 2, 42, 2, 5, 12, 434]


// récupérer l'élément placé au milieu du tableau à l'aide de la propriété .length

let middleIndex;

if (arrExample.length%2 == 0) {
    middleIndex = arrExample.length / 2
} else {
    middleIndex = (arrExample.length - 1) / 2
}

// On peut aussi faire let middleIndex : Math.round(arrExample.length / 2), ce qui va arrondir arrExample.length et évitera le problème de la virgule en cas d'impair;

// let elementInTheMiddle = arrExample[middleIndex]
// console.log(arrExample.length)
// console.log(elementInTheMiddle)

// Pour ajouter à la fin : arrExample.push(51, 14, 18, ...)

// Pour retirer à la fin : arrExample.pop() (va enlever le dernier)

// let administrators = ['Paul', 'Luc', 'Mathieu', 'Jean']
// let newAdmin = ('Marianne')
// administrators.push(newAdmin)
// let newAdmin2 = ('Sophie')
// administrators.push(newAdmin2)
// let newAdmin3 = ('Lucie')
// administrators.push(newAdmin3)

// console.log(administrators)

// Exo : Avant chaque ajout d'administrateur, on test si le nombre d'administrateurs est supérieur ou égal à 4. Si c'est le cas on enlève le dernier élément pour ajouter ensuite le nouvel administrateur

// let administrators = ['Paul', 'Luc', 'Mathieu', 'Jean']


// let newAdmin = 'Marianne'
// if (administrators.length >= 4) {
//     administrators.pop()    
// }  
//     administrators.push(newAdmin)

// console.log(administrators)


// let newAdmin2 = 'Sophie'
// if (administrators.length >= 4) {
//     administrators.pop()
//  }       
//     administrators.push(newAdmin2)

// console.log(administrators)


// let newAdmin3 = 'Lucie'
// if (administrators.length >= 4) {
//     administrators.pop()
   
// } 
//     administrators.push(newAdmin3)

// console.log(administrators)


// Ajouter utilisateur si la propriété Admin est true

// let administrators = ['Paul', 'Luc', 'Mathieu', 'Jean']

// let newAdmin = {
//     name: `Marianne`,
//     admin: true
// }

// let newAdmin2 = {
//     name:'Sophie',
//     admin: false
// }

// let newAdmin3 = {
//     name: 'Lucie',
//     admin: true
// }

// if (newAdmin.admin) {
//     administrators.push(newAdmin.name)
// }
// if (newAdmin2.admin) {
//     administrators.push(newAdmin2.name)
// }
// if (newAdmin3.admin) {
//     administrators.push(newAdmin3.name)
// }

// addUserIfAdmin(newAdmin)
// addUserIfAdmin(newAdmin2)
// addUserIfAdmin(newAdmin3)

// function addUserIfAdmin(user) {
//     if(user.admin) {
//         administrators.push(user.name)
//     }
// }

// console.log(administrators)

// Créer une fonction qui prend en paramètre un objet utilisateur et qui affiche en console 'Bonjour ${nom} !' selon l'utilisateur


// bonjour(newAdmin2)






// let newAdmin = {
//     name: `Marianne`,
//     admin: true
// }

// let newAdmin2 = {
//     name:'Sophie',
//     admin: false
// }

// let newAdmin3 = {
//     name: 'Lucie',
//     admin: true
// }


// // bonjour(newAdmin)


// // function bonjour(user) {
// //     let strResult = 'Bonjour '
// //     if(user.admin) {
// //         strResult += 'administratrice '
// //     }
    
// //     strResult += user.name + ' !'
// //     console.log(strResult)
// // }





// // multiParam(newAdmin, newAdmin2)


// // function multiParam(user1, user2) {    
// //         console.log(`Bonjour Administratice ${user1.name} et utilisateur ${user2.name} !`)    
// // }


// const town1 = {
//     name: 'Bordeaux',
//     population: 300000,
//     superficy: 50
// }

// const town2 = {
//     name: 'Lyon',
//     population: 500000,
//     superficy: 48
// }

// const town3 = {
//     name: 'Paris',
//     population: 2000000,
//     superficy: 105
// }



// // Ecrire une fonction qui prend 2 paramètres et qui affiche dans la console le nom de la ville la plus peuplé des deux

// compare(town1, town2)

// // function compare(nb1, nb2) {
// //     if (nb1.population > nb2.population) {
// //         console.log(nb1.name)
// //     } else {
// //         console.log(nb2.name)
// //     }
// // }

// function compare(nb1, nb2) {
//     if ((nb1.population)/(nb1.superficy)>(nb2.population)/(nb2.superficy)) {
//         console.log(nb1.name)
//     } else {
//         console.log(nb2.name)
//     }
// }


// Ecrire la fonction qui retourne la somme de deux paramètres


const nb1 = 5
const nb2 = 7
const sum = addTwoParameters(nb1, nb2)
function addTwoParameters (arg1, arg2) {  
    return (arg1 + arg2)
    }
console.log(`Le résultat de la somme de ${nb1} et ${nb2} est égale à ${sum}`)

// Ecrire la fonction qui retourne le produit des deux paramètres 

const resultProduct = productOfParameters(4, 6)

console.log(resultProduct)


function productOfParameters (arg1, arg2) {
    resultProduct = 4*6
}